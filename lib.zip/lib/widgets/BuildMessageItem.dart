import 'package:flutter/material.dart';
class BuildMessageItem extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
