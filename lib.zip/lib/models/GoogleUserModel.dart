class GoogleUserModel {
  String userName;
  String emailId;
  String photoUrl;

  GoogleUserModel(
    this.userName,
    this.emailId,
    this.photoUrl
  );
}